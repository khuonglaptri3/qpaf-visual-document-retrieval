"""M2.3 review interface prototype; OCR calibration is not implemented here."""
